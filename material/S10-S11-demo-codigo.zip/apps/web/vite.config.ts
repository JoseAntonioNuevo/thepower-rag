import { cloudflare } from "@cloudflare/vite-plugin";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite-plus";

export default defineConfig({
  plugins: [
    react(),
    cloudflare({
      // No hay bindings que resolver contra la cuenta. Evita el intento remoto.
      remoteBindings: false,
    }),
  ],
  server: {
    fs: {
      allow: [".", "../.."],
    },
  },
});
