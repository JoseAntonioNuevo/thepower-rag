import { useChat } from "@ai-sdk/react";
import {
  DEMO_CRAG_SCENARIOS,
  healthResponseSchema,
  type Audience,
  type ChatMode,
  type CragStep,
  type DemoScenarioId,
  type HealthResponse,
} from "@thepower-rag/contracts";
import { DefaultChatTransport, type CourseUIMessage } from "./chat";
import {
  ChatError,
  EmptyThread,
  MatrixLoader,
  PanelSlide,
  StreamedText,
  ThinkStatus,
} from "./chat-motion-view";
import { conversationStatus } from "./chat-motion";
import { acceptScenarioChange, discardedRowKey, retainedRowKey } from "./crag-panel";
import { conversationKey } from "./scope";
import { useTurnstile } from "./use-turnstile";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";

const STAGES: readonly { id: ChatMode; label: string }[] = [
  { id: "sin-rag", label: "Sin RAG" },
  { id: "rag", label: "RAG básico" },
  { id: "crag", label: "CRAG" },
];

const AUDIENCES: readonly { id: Audience; label: string }[] = [
  { id: "program", label: "General" },
  { id: "L/X", label: "Grupo con clases los lunes y miércoles" },
  { id: "M/J", label: "Grupo con clases los martes y jueves" },
];

function readableError(error: Error): string {
  const raw = error.message.trim();
  const start = raw.indexOf("{");
  if (start >= 0) {
    try {
      const parsed: unknown = JSON.parse(raw.slice(start));
      if (
        typeof parsed === "object" &&
        parsed !== null &&
        "message" in parsed &&
        typeof parsed.message === "string"
      ) {
        return parsed.message;
      }
    } catch {
      return raw || "La solicitud ha fallado.";
    }
  }
  return raw || "La solicitud ha fallado.";
}

function partText(message: CourseUIMessage): string {
  return message.parts
    .filter((part) => part.type === "text")
    .map((part) => part.text)
    .join("");
}

function capabilityNote(status: string | undefined): string {
  switch (status) {
    case "offline-demo":
      return "Demostración local, sin modelo";
    case "offline-fixture":
      return "Canalización local de prueba";
    case "ready":
      return "Proveedor configurado";
    case "blocked":
      return "Falta configuración";
    default:
      return "No implementado";
  }
}

function coverageWord(value: "complete" | "partial" | "unknown"): string {
  if (value === "complete") {
    return "completo";
  }
  if (value === "partial") {
    return "parcial";
  }
  return "desconocido";
}

function coverageText(health: HealthResponse): string {
  const coverage = health.corpus.coverage;
  return `Temario ${coverageWord(coverage.curriculum)}. Calendario L/X ${coverageWord(coverage.calendarLx)}. Calendario M/J ${coverageWord(coverage.calendarMj)}. Ejercicios ${coverageWord(coverage.exerciseDetail)}. ${coverage.remote === "index-verified" ? "Índice remoto verificado" : "Índice remoto no verificado"}.`;
}

function metric(value: number | null | undefined, offline: boolean): string {
  if (offline) {
    return "no medido";
  }
  return value === undefined || value === null ? "desconocido" : String(value);
}

function ChatPane({
  mode,
  audience,
  allowScenario,
  onBusy,
}: {
  mode: ChatMode;
  audience: Audience;
  allowScenario: boolean;
  onBusy: (busy: boolean) => void;
}) {
  const {
    container: verificationContainer,
    ready: verificationReady,
    error: verificationError,
    beforeSend,
    reset: resetVerification,
    retry: retryVerification,
  } = useTurnstile();
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [scenario, setScenario] = useState<DemoScenarioId | null>(null);
  const [liveSteps, setLiveSteps] = useState<CragStep[]>([]);
  const selectedScenario = allowScenario && mode === "crag" ? scenario : null;
  const transport = useMemo(
    () =>
      new DefaultChatTransport<CourseUIMessage>({
        api: "/api/chat",
        fetch: async (url, init) => {
          const response = await fetch(url, init);
          if (!response.ok) {
            const body = (await response.json().catch(() => null)) as { message?: string } | null;
            throw new Error(body?.message ?? `La petición respondió HTTP ${response.status}.`);
          }
          return response;
        },
        prepareSendMessagesRequest: ({ messages }) => ({
          body: {
            mode,
            audience,
            messages: messages.map((message) => ({
              id: message.id,
              role: message.role,
              parts: [{ type: "text", text: partText(message) }],
            })),
            ...(selectedScenario === null ? {} : { demoScenario: selectedScenario }),
          },
        }),
      }),
    [mode, audience, selectedScenario],
  );
  const { messages, sendMessage, status, stop, error, clearError, setMessages } =
    useChat<CourseUIMessage>({
      transport,
      onData: (part) => {
        if (part.type === "data-step") {
          setLiveSteps((current) => [...current, part.data].slice(-16));
        }
      },
    });
  const [input, setInput] = useState("");
  const busy = verifying || status === "submitted" || status === "streaming";
  useEffect(() => {
    onBusy(busy);
    return () => {
      onBusy(false);
    };
  }, [busy, onBusy]);
  const lastAssistant = [...messages].reverse().find((message) => message.role === "assistant");
  const sources = lastAssistant?.parts.filter((part) => part.type === "data-source") ?? [];
  const trace = lastAssistant?.parts.find((part) => part.type === "data-trace");
  const cragPart = lastAssistant?.parts.find((part) => part.type === "data-crag");
  const crag = cragPart?.type === "data-crag" ? cragPart.data : null;

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = input.trim();
    if (text.length === 0 || busy) {
      return;
    }
    setSubmitError(null);
    setVerifying(true);
    try {
      const verificationToken = await beforeSend();
      clearError();
      setLiveSteps([]);
      setInput("");
      await sendMessage(
        { text },
        { headers: verificationToken ? { "x-turnstile-token": verificationToken } : {} },
      );
    } catch (caught: unknown) {
      setSubmitError(caught instanceof Error ? caught.message : "No se pudo enviar la pregunta.");
    } finally {
      setVerifying(false);
      resetVerification();
    }
  }

  const statusLabel = conversationStatus(status, mode);

  return (
    <div className="layout">
      <section className="conversation" aria-label="Conversación">
        <div className="transcript" aria-live="polite">
          {messages.length === 0 ? (
            <EmptyThread text="Todavía no hay mensajes en esta conversación." />
          ) : null}
          {messages.map((message) => {
            const offline =
              message.metadata?.origin === "offline-demo" ||
              message.metadata?.origin === "offline-fixture";
            const text = partText(message);
            return (
              <PanelSlide key={message.id}>
                <article
                  className={
                    message.role === "user" ? "message message-user" : "message message-assistant"
                  }
                >
                  {message.role === "assistant" ? <StreamedText text={text} /> : <p>{text}</p>}
                  {message.role === "assistant" && message.metadata ? (
                    <p className="demo-flag">
                      {message.metadata.origin}. Estado: {message.metadata.completion}. Uso entrada:{" "}
                      {metric(message.metadata.usage?.inputTokens, offline)}. Uso salida:{" "}
                      {metric(message.metadata.usage?.outputTokens, offline)}. Coste:{" "}
                      {message.metadata.cost === null
                        ? offline
                          ? "no medido"
                          : "desconocido"
                        : message.metadata.cost.amount}
                    </p>
                  ) : null}
                </article>
              </PanelSlide>
            );
          })}
        </div>
        <div className="conversation-status" role="status">
          {busy ? (
            <span className="status-loader">
              <MatrixLoader variant="scan" />
            </span>
          ) : null}
          <ThinkStatus label={statusLabel} live={busy} />
        </div>
        {error === undefined ? null : <ChatError message={readableError(error)} />}
        {mode === "crag" && allowScenario ? (
          <label className="scenario" htmlFor="guion-crag">
            Guion de demostración
            <select
              id="guion-crag"
              value={scenario ?? ""}
              disabled={busy || !acceptScenarioChange(busy)}
              onChange={(event) => {
                if (!acceptScenarioChange(busy)) {
                  return;
                }
                const next = event.target.value;
                if (next === "") {
                  setScenario(null);
                  setMessages([]);
                  setLiveSteps([]);
                  return;
                }
                const found = DEMO_CRAG_SCENARIOS.find((item) => item.id === next);
                if (found === undefined) {
                  return;
                }
                setScenario(found.id);
                setInput(found.question);
                setMessages([]);
                setLiveSteps([]);
              }}
            >
              <option value="">Libre, con el índice lexical de prueba</option>
              {DEMO_CRAG_SCENARIOS.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
        ) : null}
        <form onSubmit={(event) => void onSubmit(event)}>
          <label htmlFor="pregunta">Pregunta</label>
          <textarea
            id="pregunta"
            value={input}
            onChange={(event) => {
              const next = event.target.value;
              setInput(next);
              if (!acceptScenarioChange(busy)) {
                return;
              }
              setScenario((current) => {
                const selected = DEMO_CRAG_SCENARIOS.find((item) => item.id === current);
                return selected !== undefined && selected.question === next ? current : null;
              });
            }}
            placeholder="Escribe una pregunta de prueba"
          />
          <div ref={verificationContainer} aria-label="Verificación de seguridad" />
          {verificationError || submitError ? (
            <p role="alert">{verificationError ?? submitError}</p>
          ) : null}
          {verificationError ? (
            <button type="button" onClick={retryVerification}>
              Reintentar verificación
            </button>
          ) : null}
          <div className="controls">
            <button
              type="submit"
              disabled={busy || !verificationReady || input.trim().length === 0}
            >
              Enviar
            </button>
            <button type="button" disabled={!busy} onClick={() => void stop()}>
              Detener
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                clearError();
                setMessages([]);
                setInput("");
              }}
            >
              Nueva conversación
            </button>
          </div>
        </form>
      </section>
      <aside className="panel">
        <section>
          <h2>Fuentes</h2>
          {sources.length === 0 ? (
            <p>
              {mode === "sin-rag"
                ? "Sin fuentes. Este modo no recupera documentos."
                : "Sin fuentes en esta respuesta."}
            </p>
          ) : (
            <ul className="cards">
              {sources.map((source) =>
                source.type === "data-source" ? (
                  <PanelSlide key={source.data.chunkId} as="li" className="card">
                    <strong>{source.data.title}</strong>
                    <span>{source.data.section}</span>
                    <span>{source.data.chunkId}</span>
                    <span>Corpus {source.data.corpusVersion}</span>
                    <p>{source.data.excerpt}</p>
                  </PanelSlide>
                ) : null,
              )}
            </ul>
          )}
        </section>
        <section>
          <h2>Traza de la clase</h2>
          {mode === "crag" ? (
            <div>
              {crag === null ? (
                <p>
                  El recorrido aparece al preguntar. En demo es un guion, no una medida de calidad.
                </p>
              ) : (
                <PanelSlide>
                  <div>
                    <p>
                      {crag.fixture ? "Guion de prueba." : "Recorrido real."} {crag.terminal}.{" "}
                      {crag.reason}
                    </p>
                    <p>
                      Búsquedas {crag.retrievalCount}. Quedan {crag.attemptsRemaining}.
                      Reformulaciones {crag.reformulationCount}. Quedan {crag.rewritesRemaining}.
                    </p>
                    <p>
                      Llamadas de pago:{" "}
                      {crag.measured ? "contadas por separado, sin total inventado" : "no medidas"}.
                      Uso:{" "}
                      {crag.usage === null
                        ? crag.measured
                          ? "desconocido"
                          : "no medido"
                        : "parcial"}
                      . Coste:{" "}
                      {crag.cost === null
                        ? crag.measured
                          ? "desconocido"
                          : "no medido"
                        : crag.cost.amount}
                      .
                    </p>
                    <p>Consulta original: {crag.originalQuestion}</p>
                    <p>Consulta de búsqueda: {crag.currentQuery}</p>
                    <ul>
                      {crag.retained.map((item, index) => (
                        <li key={retainedRowKey(item.chunkId, index)}>
                          Conservado {item.chunkId}
                          {item.score === null ? "" : ` (${item.score.toFixed(3)})`}: {item.reason}
                        </li>
                      ))}
                      {crag.discarded.map((item, index) => (
                        <li key={discardedRowKey(item, index)}>
                          Descartado {item.chunkId}, intento {item.attempt}: {item.reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                </PanelSlide>
              )}
              {liveSteps.length === 0 ? null : (
                <ol className="steps" aria-live="polite" aria-label="Pasos del grafo">
                  {liveSteps.map((step, index) => (
                    <PanelSlide key={`${step.kind}-${String(index)}`} as="li">
                      {step.kind}. Búsqueda {step.retrieval ?? 0}. {step.status}
                    </PanelSlide>
                  ))}
                </ol>
              )}
            </div>
          ) : trace?.type === "data-trace" ? (
            <PanelSlide>
              <div>
                <p>Consulta: {trace.data.query}</p>
                <p>
                  {trace.data.queryRewrite === "context-complete"
                    ? "El modelo dispone del contexto completo del grupo y del historial para interpretar seguimientos."
                    : "Reescritura de seguimiento: pendiente."}
                </p>
                <p>{trace.data.scoreMeaning}</p>
                <ul>
                  {trace.data.retrieved.map((item) => (
                    <li key={item.chunkId}>
                      {item.chunkId}:{" "}
                      {item.score === null ? "puntuación desconocida" : item.score.toFixed(3)}{" "}
                      {item.selected ? "seleccionado" : "descartado"}
                    </li>
                  ))}
                </ul>
                <p>
                  Decisión: {trace.data.decision}. Generación: {trace.data.generation}.
                </p>
                <p>{trace.data.status}</p>
              </div>
            </PanelSlide>
          ) : (
            <p>La traza aparece con la respuesta.</p>
          )}
        </section>
      </aside>
    </div>
  );
}

export function App() {
  const [mode, setMode] = useState<ChatMode>("sin-rag");
  const [audience, setAudience] = useState<Audience>("program");
  const [epoch, setEpoch] = useState(0);
  const [busy, setBusy] = useState(false);
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const onBusy = useCallback((value: boolean) => {
    setBusy(value);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void fetch("/api/health", { signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) {
          throw new Error(`El estado del servidor respondió HTTP ${String(response.status)}.`);
        }
        const parsed = healthResponseSchema.safeParse(await response.json());
        if (!parsed.success) {
          throw new Error("La respuesta de salud no cumple el contrato.");
        }
        setHealth(parsed.data);
      })
      .catch((caught: unknown) => {
        if (caught instanceof DOMException && caught.name === "AbortError") {
          return;
        }
        setHealthError(caught instanceof Error ? caught.message : "No se pudo leer el estado.");
      });
    return () => {
      controller.abort();
    };
  }, []);

  function choose(nextMode: ChatMode, nextAudience: Audience) {
    if (busy || (nextMode === mode && nextAudience === audience)) {
      return;
    }
    setMode(nextMode);
    setAudience(nextAudience);
    setEpoch((value) => value + 1);
  }

  return (
    <main className="shell">
      <header>
        <h1>Asistente del curso AI Engineer</h1>
        <p>
          Sin RAG conversa sin documentos. RAG básico recupera una vez. CRAG recorre un grafo
          correctivo acotado. En demo las decisiones son un guion de prueba.
        </p>
      </header>
      <p className="banner" role="status">
        {health === null
          ? (healthError ?? "Consultando el estado…")
          : `Perfil: ${health.execution} (${health.corpus.profileFamily}). Corpus: ${health.corpus.version ?? "sin versión"}. ${coverageText(health)} Embedding: ${health.corpus.embedding}.`}
      </p>
      <fieldset className="stages" disabled={busy}>
        <legend>Etapa</legend>
        {STAGES.map((stage) => (
          <label key={stage.id} className="stage">
            <input
              type="radio"
              name="stage"
              value={stage.id}
              checked={mode === stage.id}
              onChange={() => {
                choose(stage.id, audience);
              }}
            />
            <span>{stage.label}</span>
            <small>{capabilityNote(health?.capabilities[stage.id].status)}</small>
          </label>
        ))}
      </fieldset>
      <fieldset className="stages" disabled={busy}>
        <legend>Grupo del curso</legend>
        {AUDIENCES.map((item) => (
          <label key={item.id} className="stage">
            <input
              type="radio"
              name="audience"
              value={item.id}
              checked={audience === item.id}
              onChange={() => {
                choose(mode, item.id);
              }}
            />
            <span>{item.label}</span>
          </label>
        ))}
      </fieldset>
      <ChatPane
        key={conversationKey(mode, audience, epoch)}
        mode={mode}
        audience={audience}
        allowScenario={health?.execution === "demo"}
        onBusy={onBusy}
      />
    </main>
  );
}
