# Ejecutor privado del ensayo: conserva salida, tiempo y código de cada comando sin leer claves.
from pathlib import Path
import datetime, json, subprocess, sys, time
# El argumento inicial identifica el paso; el resto es el argv literal del comando ensayado.
folder=Path(__file__).resolve().parent
label=sys.argv[1]
argv=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
clock=time.perf_counter()
# Las salidas se guardan en el área privada del ensayo, excluida de los ZIP del curso.
with (folder/(label+'.stdout')).open('w') as out, (folder/(label+'.stderr')).open('w') as err:
 result=subprocess.run(argv,stdout=out,stderr=err,cwd=folder.parents[3])
# El recibo identifica el comando y su duración sin volcar el entorno del proceso.
record={'step':label,'argv':argv,'startedAt':started,'seconds':round(time.perf_counter()-clock,3),'exitCode':result.returncode}
(folder/(label+'.receipt.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(record,ensure_ascii=False))
# Propaga el fallo al llamador para no continuar automáticamente con pasos dependientes.
sys.exit(result.returncode)
