# Sesión de 3-rag pendiente de entrega a memoria · 21/10/2026

No se ha podido resolver la cuenta desde la ruta real del repositorio: workspace-account.sh devuelve código 1 sin account_id. No se accede a otro tenant ni se modifica infraestructura.

Alcance completado: ensayo técnico del guion S10, preparación y 24 diapositivas. Rebuild/calibración reales, baseline, RAG con fuente y rechazo, lectura del test original, respaldo offline, comprobación del QR/formulario y lectura de health. Corregidos bloques de shell visibles, rutas, operations, navegación y carga de lab/.env. Actualizados PowerPoint/PDF, guion y checklist, índice de material, evidencia por paso y tres ZIP.

Comprobación: esquema local 10 documentos y 20 vectores de 768 con HNSW, corte 0.724767. Respuesta AES-256-GCM/72 horas con cita, similitud 0.814425. Rechazo a 0.70153 sin generador. Test original 9/14 + 6/6 conservado, sin reejecutar. Aplicación y laboratorio sin cambios de fuentes. Check correcto (379/221), 316 tests en 52 archivos, cuatro fuentes Python compiladas. Guion PDF 11 páginas, presentación 24. Render idéntico en 21 diapositivas; solo 13/15/17 cambian sus comandos. Verdana y Courier New conservadas tras corregir la configuración local del exportador. ZIP: 375/180/9 entradas, todas coinciden con su fuente.

Doce llamadas nuevas, reserva adicional 0.047165 USD; acumulado 0.3106076 de un tope 1 USD. Coste facturado desconocido. Sin despliegue ni mensajes a terceros, sin commit/push. La programación 30+50+10 está verificada; no se presenta como un ensayo oral cronometrado con alumnos.

Evidencia canónica: material/S10/evidencias/ensayo-paso-a-paso-20261021.md y carpeta ensayo-20261021. Aprendizajes: probar la expansión de los comandos que aparecen en las diapositivas, usar rutas completas desde el cwd previsto, contrastar los campos del recibo real y comprobar fuentes/píxeles tras exportar PDF. No tocar el test ni el diario de presupuesto para repetir una demo.
