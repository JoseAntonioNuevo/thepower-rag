# Cambia únicamente autoría docente: comandos visibles completos y referencias exactas a archivos y campos.
from pathlib import Path
import ast, json
root=Path(__file__).resolve().parents[4]
source=root/'material/S10/fuentes/preparar-contenido.py'
text=source.read_text()
data=json.loads((root/'material/S10/fuentes/contenido.json').read_text())
# La barra final concatena las dos cadenas sin añadir un salto ni cambiar la pregunta ensayada.
question=data[12]['code'].split("--question '",1)[1].split("' --execute",1)[0]
negative=data[16]['code'].split("--question '",1)[1].split("' --execute",1)[0]
make=lambda prefix,tail,command,brief: "pregunta='"+prefix+"'\\\n'"+tail+"'\nbun run lab:real "+command+' --question "$pregunta" \\\n  --execute --max-spend-usd 1'+(' --brief' if brief else '')
codes={13:make('¿Con qué algoritmo se cifran los volúmenes en reposo y ','qué periodo de enfriamiento exige destruir una CMK?','baseline',False),15:make('¿Con qué algoritmo se cifran los volúmenes en reposo y ','qué periodo de enfriamiento exige destruir una CMK?','query',True),17:make('¿Qué coste mensual tienen las licencias de ','Windows Server 2025 en AetherCloud?','query',True)}
# Sustituye los literales de code en la fuente Python, conservando el resto de su código y comentarios.
lines=text.splitlines(keepends=True);edits=[]
for node in ast.walk(ast.parse(text)):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='add':
  start=node.args[0].value;slide=next(i+1 for i,s in enumerate(data) if s['start']==start and s['title']==node.args[2].value)
  if slide in codes:
   value=next(k.value for k in node.keywords if k.arg=='code')
   # Las columnas AST son bytes UTF-8, por lo que se convierten antes de sustituir la fuente.
   begin=sum(len(s) for s in lines[:value.lineno-1])+len(lines[value.lineno-1].encode()[:value.col_offset].decode())
   end=sum(len(s) for s in lines[:value.end_lineno-1])+len(lines[value.end_lineno-1].encode()[:value.end_col_offset].decode())
   edits.append((begin,end,repr(codes[slide])))
for begin,end,new in sorted(edits,reverse=True):text=text[:begin]+new+text[end:]
# Las rutas se resuelven desde 3-rag, el mismo cwd que requieren los comandos de la clase.
replacements={
 'Abre, si hace falta, /api/health de la web y señala ragContextMode: semantic.':'Abre, si hace falta, https://rag-thepower.josenuevo.dev/api/health y señala modelConfiguration.ragContextMode: semantic.',
 'usa la copia del fragmento incluida en el recibo consulta-con-fuentes.json.':'usa la copia del fragmento incluida en material/S10/evidencias/consulta-con-fuentes.json.',
 'Abre lab/.local/calibration.json o su copia de evidencias.':'Abre lab/.local/calibration.json o material/S10/evidencias/calibracion-real.json.',
 'Ejecuta el comando baseline de abajo.':'Ejecuta las cuatro líneas del comando baseline de abajo, incluida la asignación de pregunta.',
 'Abre evidencias/sin-documentos.json':'Abre material/S10/evidencias/sin-documentos.json',
 'Abre después corpus.ts, embeddings del adaptador real y rebuildFromEmptyIndex.':'Abre lab/src/corpus.ts (prepareLabCorpusFromDirectory), apps/api/src/lab-models.ts (embed) y lab/src/pgvector-store.ts (rebuildFromEmptyIndex).',
 'Usa evidencias/indice-real.json.':'Usa material/S10/evidencias/indice-real.json.',
 'Ejecuta query con --brief.':'Ejecuta las cuatro líneas de query con --brief, incluida la asignación de la misma pregunta que en baseline.',
 'Abre consulta-con-fuentes.json y el Markdown fuente.':'Abre material/S10/evidencias/consulta-con-fuentes.json y lab/corpus/sources/04-almacenamiento-y-cifrado-kms.md.',
 'para ver retrieved, selected, citations, usage y latencia.':'para ver result.retrieved, result.selected, result.citations, result.latencyMs y los tokens en operations. Antes de la siguiente consulta, copia el recibo si quieres conservarlo.',
 'Ejecuta la pregunta con --brief.':'Ejecuta las cuatro líneas de la pregunta sin respuesta con --brief.',
 'Abre evidencias/consulta-rechazada.json':'Abre material/S10/evidencias/consulta-rechazada.json',
 'Abre corpus/sources/cohorts/calendario-mj.md y calendario-lx.md.':'Abre corpus/sources/cohorts/calendario-mj.md y corpus/sources/cohorts/calendario-lx.md.',
 'Muestra en código dónde se aplica el filtro antes de construir el contexto.':'Abre apps/api/src/stores.ts y muestra audienceFilter y el filtro audience de queryVectorize antes de construir el contexto.',
 'Abre material/S10/evidencias/evaluacion-real-resumen.md y dos filas del recibo completo.':'Abre material/S10/evidencias/evaluacion-real-resumen.md y material/S10/evidencias/evaluacion-real.json. Contrasta los casos 1 (completo) y 4 (abstención incorrecta).',
 'Abre material/ejercicios/S10-enunciado.md y laboratorio-apoyo.md.':'Abre material/ejercicios/S10-enunciado.md y material/ejercicios/laboratorio-apoyo.md.',
 'La plantilla está en `lab/.env.example`; si la usas, invoca Bun con `--env-file=lab/.env` según la guía del laboratorio.':'La plantilla está en `lab/.env.example`. El propio CLI carga `lab/.env` con prioridad sobre el entorno: usa los comandos tal como aparecen aquí, sin añadir `--env-file`.',
 'Localiza ORDER BY y LIMIT.':'Localiza ORDER BY y LIMIT. El bloque SQL de la diapositiva muestra fragmentos del esquema y la consulta, no una sentencia completa para pegar en la terminal.',
 'localiza ORDER BY y LIMIT.':'localiza ORDER BY y LIMIT. El bloque SQL de la diapositiva muestra fragmentos del esquema y la consulta, no una sentencia completa para pegar en la terminal.',
}
for old,new in replacements.items():
 if old in text:text=text.replace(old,new)
 else:print('Variante no presente:',old)
# Explica una sola vez las líneas continuadas para que la versión legible siga siendo copiable.
old='5. Ensaya una vez las preguntas de las diapositivas 13, 15 y 17.'
new='5. Ensaya una vez las preguntas de las diapositivas 13, 15 y 17. Copia cada bloque completo de cuatro líneas: las dos primeras asignan una única pregunta sin introducir saltos en su texto y las otras dos ejecutan Bun. Las barras finales continúan la misma instrucción de shell.'
assert old in text;text=text.replace(old,new)
source.write_text(text)
# El generador de diapositivas debe mostrar literalmente el mismo bloque del guion y las notas.
p=root/'material/S10/fuentes/generar-presentacion.mjs';js=p.read_text()
a=js.index('      // Parte del comando completo que se mantiene en el contenido editable.')
b=js.index('\n    }\n  }',a)
js=js[:a]+'''      // Muestra el bloque íntegro y copiable que comparten el guion y las notas del profesor.
      // Las barras de continuación mantienen la misma pregunta sin añadir saltos a su valor.
      text(slide, s.code, 64, 453, 1140, 170, 23, accent, false, "Courier New");'''+js[b:]
p.write_text(js)
# Sustituye una referencia a una línea antigua por los símbolos estables que debe buscar el profesor.
p=root/'material/notas/checklist-preclase.md';check=p.read_text();check=check.replace('`apps/api/src/app.ts` (línea 670, recorrido semántico) y `lab/src/rag-basic.ts` (umbral previo y bloque `DATOS`).','`apps/api/src/stores.ts` (`audienceFilter` y `queryVectorize`), `apps/api/src/lab-models.ts` (embeddings y generación reales) y `lab/src/rag-basic.ts` (`runLabBasicRag`, umbral previo y bloque `DATOS`).')
check=check.replace('## Específico de S10 (jueves 22 de octubre)\n','''## Específico de S10 (jueves 22 de octubre)

- Antes del directo: `bun run lab:real preflight` y `bun run lab:real status`; deben confirmar modelos reales, 768 dimensiones, 20 fragmentos y HNSW. El recorrido de `lab:demo` de arriba es solo respaldo.
- Ten localizados `lab/.local/calibration.json`, `material/S10/evidencias/evaluacion-real-resumen.md` y las copias JSON de `material/S10/evidencias/`. El test ya ejecutado se lee, no se repite en clase.
- Copia íntegros los bloques de cuatro líneas del guion para baseline y consultas: incluyen la asignación de la pregunta y las barras de continuación. Son los mismos que muestra el PowerPoint.
''')
p.write_text(check)
compile(text,str(source),'exec')
print('Fuentes docentes alineadas; el código de la aplicación no se modifica')
