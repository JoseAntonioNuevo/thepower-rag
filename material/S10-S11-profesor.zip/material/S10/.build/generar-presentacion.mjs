// GUÍA DE LECTURA · material/S10/fuentes/generar-presentacion.mjs
// Autoría editable con Artifact Tool; contenido y notas proceden de la misma secuencia del guion.
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { Presentation, PresentationFile } from "@oai/artifact-tool";
const repo = path.resolve(process.argv[2] ?? ".");
const folder = path.join(repo, "material/S10");
const build = path.join(folder, ".build");
const data = JSON.parse(await fs.readFile(path.join(folder, "fuentes/contenido.json"), "utf8"));
const skill = process.env.PRESENTATIONS_SKILL;
const python = process.env.RUNTIME_PYTHON;
if (!skill || !python)
  throw new Error("Configura PRESENTATIONS_SKILL y RUNTIME_PYTHON con el runtime de Codex.");
const { finalizePresentation } = await import(
  pathToFileURL(path.join(skill, "container_tools/artifact_tool_utils.mjs")).href
);
const deck = Presentation.create({ slideSize: { width: 1280, height: 720 } });
const navy = "#081D2B",
  teal = "#007C78",
  mint = "#4DDAC8",
  ink = "#102D39",
  paper = "#F8FAF9";
const clock = (m) =>
  `${String(18 + Math.floor((30 + m) / 60)).padStart(2, "0")}:${String((30 + m) % 60).padStart(2, "0")}`;
function text(slide, value, x, y, w, h, size = 26, color = ink, bold = false, font = "Verdana") {
  const s = slide.shapes.add({
    name: "texto-" + slide.shapes.items.length,
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { fill: "none", width: 0 },
  });
  s.text = value;
  s.text.style = {
    typeface: font,
    fontSize: size,
    color,
    bold,
    verticalAlignment: "top",
    autoFit: "none",
    insets: 0,
    wrap: "square",
    lineSpacing: 1.15,
  };
  return s;
}
async function image(slide, name, x, y, w, h, fit = "contain") {
  const p = path.join(folder, "fuentes/assets", name);
  const b = await fs.readFile(p);
  slide.images.add({
    blob: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength),
    contentType: "image/png",
    alt: name,
    fit,
    position: { left: x, top: y, width: w, height: h },
  });
}
for (const [index, s] of data.entries()) {
  const slide = deck.slides.add();
  const dark = [0, 5, 7, 11, 12, 14, 16, 20, 22].includes(index);
  slide.background.fill = dark ? navy : paper;
  const fg = dark ? "#FFFFFF" : ink,
    accent = dark ? mint : teal;
  const block =
    index < 12
      ? "CONCEPTOS"
      : index < 20
        ? "APLICACIÓN Y CÓDIGO"
        : index < 23
          ? "CIERRE"
          : "CONSULTA";
  text(slide, `S10 · ${block}`, 64, 38, 950, 30, 15, accent, true);
  text(
    slide,
    index === 23 ? "Apéndice" : `${clock(s.start)}–${clock(s.end)}`,
    1030,
    38,
    190,
    30,
    15,
    accent,
    false,
  );
  if (index === 0) {
    await image(slide, "portada.png", 0, 0, 1280, 720, "cover");
    text(slide, "S10 · AI ENGINEER", 66, 55, 600, 32, 18, mint, true);
    text(slide, "RAG", 66, 150, 620, 100, 78, "#FFFFFF", true);
    text(slide, "Chatbot con\ndocumentación propia", 66, 268, 650, 130, 44, "#FFFFFF", true);
    text(
      slide,
      "José Antonio Nuevo\n22 octubre 2026 · 18:30–20:00",
      66,
      510,
      720,
      75,
      23,
      "#FFFFFF",
    );
    text(slide, "30 conceptos  /  50 práctica  /  10 cierre", 66, 622, 800, 36, 22, mint);
  } else {
    text(slide, s.title, 64, 100, 1150, 110, 43, fg, true);
    const withImage = index === 7,
      qr = index === 1;
    const width = withImage || qr ? 640 : 1120;
    const lineHeight = s.code ? 62 : 100;
    for (const [i, line] of s.body.entries())
      text(slide, line, 64, 235 + i * lineHeight, width, lineHeight - 8, s.code ? 25 : 28, fg);
    if (withImage) await image(slide, "embedding.png", 760, 240, 450, 360, "contain");
    if (qr) {
      const b = await fs.readFile(path.join(repo, "material/assets/qr-ai-engineer.jpg"));
      slide.images.add({
        blob: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength),
        contentType: "image/jpeg",
        alt: "QR de evaluación de AI Engineer, actualizado por Laura el 19 de octubre",
        fit: "contain",
        position: { left: 790, top: 220, width: 390, height: 390 },
      });
    }
    if (s.code) {
      let code = s.code;
      if (code.includes("--question"))
        code =
          "bun run lab:real " +
          (code.includes("baseline") ? "baseline" : "query") +
          " --question '…'\n  --execute --max-spend-usd 1" +
          (code.includes("--brief") ? " --brief" : "");
      text(slide, code, 64, 453, 1140, 170, 23, accent, false, "Courier New");
    }
  }
  text(slide, "thePower · AI Engineer · RAG", 64, 677, 900, 22, 13, dark ? "#B7D0D4" : "#4E6972");
  text(
    slide,
    `${String(index + 1).padStart(2, "0")} / ${String(data.length).padStart(2, "0")}`,
    1110,
    677,
    100,
    22,
    13,
    dark ? "#B7D0D4" : "#4E6972",
  );
  slide.speakerNotes.text = `${clock(s.start)}–${clock(s.end)} · ${s.title}\n\nDI\n${s.say}\n\nHAZ\n${s.do}\n${s.code}\n\nCOMPRUEBA\n${s.check}\n\nSI FALLA\n${s.fallback}\n\nFUENTES\nGuion canónico de S10 y evidencias del ensayo local real.\nhttps://github.com/pgvector/pgvector\nhttps://ai-sdk.dev/providers/ai-sdk-providers/google`;
}
await fs.mkdir(build, { recursive: true });
await fs.mkdir(path.join(build, "final"), { recursive: true });
const stamp = Date.now();
const candidate = path.join(build, `candidato-${stamp}.pptx`);
await (await PresentationFile.exportPptx(deck)).save(candidate);
const target = path.join(build, "final", `validado-${stamp}.pptx`);
const result = await finalizePresentation({
  workspaceDir: folder,
  candidatePath: candidate,
  finalPath: target,
  pythonExecutable: python,
  integrityValidatorPath: path.join(
    skill,
    "container_tools/inspect_presentation_package_integrity.py",
  ),
  layoutValidatorPath: path.join(skill, "container_tools/inspect_presentation_layout_geometry.py"),
  layoutArgs: ["--expected-slide-size-emu", "12192000,6858000", "--validate-heading-fit"],
  fontPolicy: { basis: "design", families: ["Verdana", "Courier New"] },
  verifyArtifactToolImport: true,
  receiptPath: path.join(build, `validacion-${stamp}.json`),
});
await fs.copyFile(target, path.join(repo, "material/presentaciones/S10-rag-basico.pptx"));
console.warn(
  JSON.stringify({
    slides: data.length,
    file: "material/presentaciones/S10-rag-basico.pptx",
    validation: result,
  }),
);
