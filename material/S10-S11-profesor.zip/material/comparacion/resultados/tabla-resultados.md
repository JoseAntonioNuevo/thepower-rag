# Comparación real de RAG básico y CRAG

Ejecutada el 3 de octubre de 2026 contra https://rag-thepower.josenuevo.dev. Veinte preguntas reservadas por etapa, 40 resultados. Conversaciones nuevas. Configuración congelada: GPT-6 Luna priority, razonamiento none, BGE-M3 1024 dimensiones, perfil p76509a5f9743, umbral 0,50. No se cambiaron prompts, modelos ni umbral después del lote.

La valoración es manual según los criterios previos. Este conjunto pequeño no estima una tasa general de calidad. Los tokens y costes de cada respuesta corresponden a la generación final; las evaluaciones, reformulaciones y embeddings no están incluidos en ese importe. Los valores ausentes permanecen desconocidos.

| Etapa | Correctas | Respondibles | Sin apoyo | Mediana de duración |
|---|---:|---:|---:|---:|
| rag | 17/20 | 11/14 | 6/6 | 1193 ms |
| crag | 18/20 | 13/14 | 5/6 | 4304 ms |

## Lectura de los resultados

- Ambos confundieron «cuándo plantea S7» con calendario y pidieron una cohorte innecesaria. Es un defecto del detector de intención previo a la recuperación.
- RAG básico rechazó las preguntas de S11 y S12 que sí tenían apoyo. El umbral conservador evita falsos apoyos en desarrollo y puede perder respuestas.
- CRAG respondió esas dos preguntas, pero en la petición del correo de Ignacio terminó con un error controlado del evaluador. No inventó un correo; tampoco completó el rechazo esperado.
- No se observan fechas, aulas, correos, versiones o precios inventados en las 40 respuestas revisadas.
- Estos resultados se conservan. No se ha ajustado el sistema al conjunto reservado ni se presenta HTTP 200 como prueba de respuesta correcta.

## Detalle por pregunta

| Pregunta | Etapa | Correcta | Final | Búsquedas | Reformulaciones | Duración ms |
|---:|---|---|---|---:|---:|---:|
| 1 | rag | Sí | complete | 1 | 0 | 2174 |
| 2 | rag | Sí | complete | 1 | 0 | 1580 |
| 3 | rag | Sí | complete | 1 | 0 | 1355 |
| 4 | rag | Sí | complete | 1 | 0 | 1229 |
| 5 | rag | Sí | complete | 1 | 0 | 1234 |
| 6 | rag | No | clarified | 0 | 0 | 107 |
| 7 | rag | Sí | complete | 1 | 0 | 1382 |
| 8 | rag | No | refused | 1 | 0 | 469 |
| 9 | rag | No | refused | 1 | 0 | 417 |
| 10 | rag | Sí | complete | 1 | 0 | 1304 |
| 11 | rag | Sí | complete | 1 | 0 | 1156 |
| 12 | rag | Sí | complete | 1 | 0 | 1290 |
| 13 | rag | Sí | complete | 1 | 0 | 1199 |
| 14 | rag | Sí | complete | 1 | 0 | 1257 |
| 15 | rag | Sí | refused | 1 | 0 | 476 |
| 16 | rag | Sí | refused | 1 | 0 | 439 |
| 17 | rag | Sí | refused | 1 | 0 | 423 |
| 18 | rag | Sí | complete | 1 | 0 | 1187 |
| 19 | rag | Sí | refused | 1 | 0 | 598 |
| 20 | rag | Sí | refused | 1 | 0 | 472 |
| 1 | crag | Sí | complete | 1 | 0 | 4312 |
| 2 | crag | Sí | complete | 1 | 0 | 4414 |
| 3 | crag | Sí | complete | 1 | 0 | 3874 |
| 4 | crag | Sí | complete | 1 | 0 | 3720 |
| 5 | crag | Sí | complete | 1 | 0 | 5164 |
| 6 | crag | No | clarified | 0 | 0 | 94 |
| 7 | crag | Sí | complete | 1 | 0 | 4175 |
| 8 | crag | Sí | complete | 1 | 0 | 4927 |
| 9 | crag | Sí | complete | 1 | 0 | 3847 |
| 10 | crag | Sí | complete | 1 | 0 | 4052 |
| 11 | crag | Sí | complete | 1 | 0 | 3890 |
| 12 | crag | Sí | complete | 1 | 0 | 3665 |
| 13 | crag | Sí | complete | 1 | 0 | 4295 |
| 14 | crag | Sí | complete | 1 | 0 | 3622 |
| 15 | crag | Sí | refused | 3 | 2 | 11307 |
| 16 | crag | Sí | refused | 3 | 2 | 10120 |
| 17 | crag | Sí | refused | 3 | 2 | 11071 |
| 18 | crag | Sí | refused | 3 | 2 | 10498 |
| 19 | crag | No | error | 3 | 2 | 10477 |
| 20 | crag | Sí | refused | 3 | 2 | 11365 |
