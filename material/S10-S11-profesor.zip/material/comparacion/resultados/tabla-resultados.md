# Evaluación histórica congelada de RAG básico y CRAG (3 de octubre de 2026)

> **Aviso de procedencia histórica:** estos 40 resultados reales se ejecutaron el **3 de octubre de 2026** contra `https://rag-thepower.josenuevo.dev` con la referencia congelada de ese día (`openai/gpt-6-luna`, razonamiento `none`, BGE-M3 `1024` dimensiones, perfil `p76509a5f9743`, umbral semántico `0,50`, en `resultados/configuracion-congelada.json`). Con posterioridad a esa fecha cambiaron tres archivos congelados (`apps/api/src/prompts.ts`, `apps/api/src/crag-real.ts` y `apps/api/src/model.ts`) al pasar la generación y evaluación a `claude-haiku-5-5` (Anthropic) y separar los nodos `rank` y `assess` con escala `[0, 1]`. **Se conservan como evidencia histórica de aquella versión y no se atribuyen al código actual.**
>
> Para la evaluación ejecutada sobre el **laboratorio reproducible del ejercicio (`vector(768)` + HNSW, 10 documentos ficticios)** consulta [`../../../lab/eval/resultados-laboratorio.md`](../../../lab/eval/resultados-laboratorio.md). Para el nuevo conjunto reservado congelado sobre la referencia actual (`claude-haiku-5-5` + `RAG_CONTEXT_MODE=semantic`) consulta [`../conjunto-reservado-referencia-actual-20.md`](../conjunto-reservado-referencia-actual-20.md).

La valoración es manual según los criterios previos. Este conjunto pequeño de 20 preguntas por etapa no estima una tasa general de calidad. Los tokens y costes de cada respuesta corresponden a la generación final; las evaluaciones, reformulaciones y embeddings no están incluidos en ese importe. Los valores ausentes permanecen desconocidos.

| Variante histórica (03/10/2026) | Total correctas | Respondibles correctas | Rechazos correctos | Recuperaciones medias | Reformulaciones medias | Mediana de duración |
|---|---:|---:|---:|---:|---:|---:|
| RAG básico (semántico, corte 0,50) | 17/20 | 11/14 | 6/6 | 0,95 | 0,00 | 1193 ms (1,193 s) |
| CRAG (máx. 3 búsquedas, 2 reformulaciones) | 18/20 | 13/14 | 5/6 | 1,55 | 0,60 | 4304 ms (4,304 s) |

## Lectura de los resultados históricos

- **Recuperaciones medias por pregunta:** RAG básico realizó `19` búsquedas en `20` preguntas (`0,95` de media, porque la pregunta 6 activó aclaración previa con `0` búsquedas). CRAG realizó `31` búsquedas y `12` reformulaciones en `20` preguntas (`1,55` recuperaciones medias y `0,60` reformulaciones medias: `1` búsqueda en las respondibles resueltas a la primera y `3` búsquedas con `2` reformulaciones en las 6 preguntas sin apoyo documental).
- **Fallo compartido en detector de calendario (pregunta 6):** ambos confundieron *«cuándo plantea S7»* con una consulta de calendario y pidieron cohorte sin buscar (`0` búsquedas).
- **Falsos rechazos del umbral fijo frente a recuperación en CRAG (preguntas 8 y 9):** RAG básico rechazó las preguntas de S11 y S12 que sí tenían apoyo en el corpus porque su coseno quedó bajo `0,50`. CRAG sí las respondió (`13/14` frente a `11/14`).
- **Fallo controlado del evaluador en CRAG (pregunta 19):** en la consulta por el correo de Ignacio para tutorías, CRAG agotó 3 búsquedas y 2 reformulaciones y terminó con `error` del evaluador en lugar de `refused` (`5/6` rechazos limpios frente a `6/6` en RAG básico). No inventó ningún correo.
- No se observan fechas, aulas, correos, versiones o precios inventados en las 40 respuestas revisadas.

## Detalle por pregunta (lote histórico del 03/10/2026)

| Pregunta | Etapa | Correcta | Final | Búsquedas | Reformulaciones | Duración ms |
|---:|---|---|---|---:|---:|---:|
| 1 | rag | Sí | complete | 1 | 0 | 2174 |
| 2 | rag | Sí | complete | 1 | 0 | 1580 |
| 3 | rag | Sí | complete | 1 | 0 | 1355 |
| 4 | rag | Sí | complete | 1 | 0 | 1229 |
| 5 | rag | Sí | complete | 1 | 0 | 1234 |
| 6 | rag | No | clarified | 0 | 0 | 107 |
| 7 | rag | Sí | complete | 1 | 0 | 1382 |
| 8 | rag | No | refused | 1 | 0 | 469 |
| 9 | rag | No | refused | 1 | 0 | 417 |
| 10 | rag | Sí | complete | 1 | 0 | 1304 |
| 11 | rag | Sí | complete | 1 | 0 | 1156 |
| 12 | rag | Sí | complete | 1 | 0 | 1290 |
| 13 | rag | Sí | complete | 1 | 0 | 1199 |
| 14 | rag | Sí | complete | 1 | 0 | 1257 |
| 15 | rag | Sí | refused | 1 | 0 | 476 |
| 16 | rag | Sí | refused | 1 | 0 | 439 |
| 17 | rag | Sí | refused | 1 | 0 | 423 |
| 18 | rag | Sí | complete | 1 | 0 | 1187 |
| 19 | rag | Sí | refused | 1 | 0 | 598 |
| 20 | rag | Sí | refused | 1 | 0 | 472 |
| 1 | crag | Sí | complete | 1 | 0 | 4312 |
| 2 | crag | Sí | complete | 1 | 0 | 4414 |
| 3 | crag | Sí | complete | 1 | 0 | 3874 |
| 4 | crag | Sí | complete | 1 | 0 | 3720 |
| 5 | crag | Sí | complete | 1 | 0 | 5164 |
| 6 | crag | No | clarified | 0 | 0 | 94 |
| 7 | crag | Sí | complete | 1 | 0 | 4175 |
| 8 | crag | Sí | complete | 1 | 0 | 4927 |
| 9 | crag | Sí | complete | 1 | 0 | 3847 |
| 10 | crag | Sí | complete | 1 | 0 | 4052 |
| 11 | crag | Sí | complete | 1 | 0 | 3890 |
| 12 | crag | Sí | complete | 1 | 0 | 3665 |
| 13 | crag | Sí | complete | 1 | 0 | 4295 |
| 14 | crag | Sí | complete | 1 | 0 | 3622 |
| 15 | crag | Sí | refused | 3 | 2 | 11307 |
| 16 | crag | Sí | refused | 3 | 2 | 10120 |
| 17 | crag | Sí | refused | 3 | 2 | 11071 |
| 18 | crag | Sí | refused | 3 | 2 | 10498 |
| 19 | crag | No | error | 3 | 2 | 10477 |
| 20 | crag | Sí | refused | 3 | 2 | 11365 |
